﻿using System;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void folderBrowserDialog1_HelpRequest(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load_1(object sender, EventArgs e)
        {

        }

        public void button1_Click(object sender, EventArgs e)
        {
            string path = textBox1.Text;
            converter.convert(path);
        }

        public void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
    public class converter
    {
        public static void convert(string path)
        {
            //Вывод в ту же директорию, но .csv
            string csv_path = path;
            csv_path = csv_path.Replace("bmp", "csv");
           
                GetBitMapColorMatrix(path, csv_path);
            MessageBox.Show("Вывод успешно завершен в файлы " + csv_path + "  и  " + csv_path.Replace(".csv", "_info.txt"));
        }
        //Функция получения ARGB каждого пикселя
        public static void GetBitMapColorMatrix(string bitmapFilePath, string csv_path)
        {
            //writer
            Encoding enc = Encoding.GetEncoding(1251);
            FileStream output = new FileStream(csv_path, FileMode.Create);
            StreamWriter writer = new StreamWriter(output, enc);
            //Сам метод
            Color colorMatrix; //объявляем
            using (var b1 = new Bitmap(bitmapFilePath))
            {
                b1.RotateFlip(RotateFlipType.Rotate270FlipY);
                int hight = b1.Height;
                int width = b1.Width;
                colorMatrix = new Color(); //инициализируем
                for (int i = 0; i < width; i++)
                {
                  
                    for (int j = 0; j < hight; j++)
                    {
                        colorMatrix = b1.GetPixel(i, j);
                        writer.Write(colorMatrix + ";"); //Тут же печатаем
                    }
                    writer.Write("\n");
                }
                writer.Close();
                string info_path = csv_path.Replace(".csv", "_info.txt");
                //string[] pixelFormat = b1.PixelFormat.ToString().Replace("Format", "").Replace("bpp", ";").Split(';');
                //string[] info_contain = new string[3]; info_contain[0] = "размер изоображения:" + b1.Height + "x" + b1.Width; info_contain[1] = "количество байт на пиксель:" + pixelFormat[0]; //info_contain[2] = "формат пикселей:" + pixelFormat[1];
                //File.WriteAllLines(info_path, info_contain, Encoding.UTF8);// создание документа по важным критериям  этого файла
                header.getheader(bitmapFilePath, info_path);

            }
           // return colorMatrix;
        }
    }
    class header
    {

        static string convertFromByteArrayIoInt(byte[] input)
        {
            int output = 0;

            for (int i = 0; i < input.Length; i++)

                output += input[i] << (i * 8);

            return output.ToString();
        }


        public static void getheader(string textFile, string info_path)
        {
           // string textFile;
            byte[] InputByte1;
            // for (;;)
            {
                {
                    //Console.WriteLine("\nвведите путь до файла bmp");
                    string path1 = textFile;
                    InputByte1 = File.ReadAllBytes(path1);
                    //Console.WriteLine("\n");
                    textFile = File.ReadAllText(path1);                                                                                                                                          //
                }
                int word = 2;
                int dword = 4;
                byte[] toInt2 = new byte[word];
                byte[] toInt4 = new byte[dword];
                string[] mass = new string[32];//for output // 5    +5/ +11/ +20/ +25 =>30 +2 (служ)
                string extra = " / ";
                int index = 0;
                int position = 0;
                byte[] revese36 = new byte[36];
                //////////////////////////////
                // main point
                string MainPoint1; // положение пиксельных данных
                string MainPoint2; // размер структуры BITMAPINFO
                                   //////////////////////////////
                Encoding enc = Encoding.GetEncoding(1251);
                FileStream output = new FileStream(info_path, FileMode.Create);
                StreamWriter writer = new StreamWriter(output, enc);
                ////////////
                // bfType
                mass[index] = "(length: 2 bytes) (сигнатура файла) bfType: ";
                for (int i = 0; i < word; i++)
                {
                    //  mass[index] = mass[index]+ InputByte1[position].ToString() +" ";
                    extra = InputByte1[position].ToString("X2") + " " + extra;

                    position++;
                }
                mass[index] += extra;
                mass[index] += textFile[0].ToString() + textFile[1].ToString();
                extra = " / ";
                index++;
                // bfSize
                mass[index] = "(length: 4 bytes) (размер файла (в байтах)) bfSize: ";
                for (int i = 0; i < dword; i++)
                {
                    //  mass[index] = mass[index]+ InputByte1[position].ToString() + " ";
                    extra = InputByte1[position].ToString("X2") + " " + extra;
                    toInt4[i] = InputByte1[position];
                    position++;
                }
                mass[index] += extra + convertFromByteArrayIoInt(toInt4);
                extra = "";
                index++;
                // bfReserved1
                mass[index] = "(length: 2 bytes) (зарезервированные пустые байты) bfReserved1: ";
                for (int i = 0; i < word; i++)
                {
                    // mass[index] = mass[index]+ InputByte1[position].ToString() + " ";
                    extra = InputByte1[position].ToString("X2") + " " + extra;
                    position++;
                }
                mass[index] += extra;
                extra = "";
                index++;
                // bfReserved2
                mass[index] = "(length: 2 bytes) (зарезервированные пустые байты) bfReserved2: ";
                for (int i = 0; i < word; i++)
                {
                    // mass[index] = mass[index]+ InputByte1[position].ToString() + " ";
                    extra = InputByte1[position].ToString("X2") + " " + extra;
                    position++;
                }
                mass[index] += extra;
                extra = "";
                index++;
                // bfOffBits
                mass[index] = "(length: 4 bytes) (положение пиксельных данных (в байтах)) bfOffBits: ";
                for (int i = 0; i < dword; i++)
                {
                    //  mass[index] = mass[index]+ InputByte1[position].ToString() + " ";
                    extra = InputByte1[position].ToString("X2") + " " + extra;
                    toInt4[i] = InputByte1[position];
                    position++;
                }
                MainPoint1 = convertFromByteArrayIoInt(toInt4);
                mass[index] += extra + " / " + MainPoint1;
                extra = "";
                index++;
                writer.WriteLine("BITMAPFILEHEADER\n");
                // BITMAPINFOHEADER
                mass[index] = "\nBITMAPINFOHEADER";
                index++;
                // b Size

                mass[index] = "(length: 4 bytes)(размер этой структуры, который определяет версию) b Size: ";
                for (int i = 0; i < dword; i++)
                {
                    //  massInfo[index] += InputByte1[position].ToString() + " ";
                    extra = InputByte1[position].ToString("X2") + " " + extra;
                    toInt4[i] = InputByte1[position];
                    position++;
                }
                MainPoint2 = convertFromByteArrayIoInt(toInt4);
                string type = "-";
                {
                    if (toInt4[0] == 12) type = "CORE";
                    else
                    if (toInt4[0] == 40) type = "ver 3";
                    else
                    if (toInt4[0] == 108) type = "ver 4";
                    else
                    if (toInt4[0] == 124) type = "ver 5";
                    else
                    {
                        type = "not intedeficated";
                    }
                }
                mass[index] += extra + " / " + MainPoint2 + " / version: " + type;
                extra = "";
                index++;
                int checkCORE = 0;
                if (type == "CORE") checkCORE = word; else checkCORE = dword;
                // width
                mass[index] = "(length: 4 bytes) (ширина) width: ";
                for (int i = 0; i < checkCORE; i++)
                {
                    // massInfo[index] += InputByte1[position].ToString() + " ";
                    extra = InputByte1[position].ToString("X2") + " " + extra;
                    toInt4[i] = InputByte1[position];
                    position++;
                }
                mass[index] += extra + " / " + convertFromByteArrayIoInt(toInt4);
                extra = "";
                index++;
                // height
                mass[index] = "(length: 4 bytes) (высота) height: ";
                for (int i = 0; i < checkCORE; i++)
                {
                    // massInfo[index] += InputByte1[position].ToString() + " ";
                    extra = InputByte1[position].ToString("X2") + " " + extra;
                    toInt4[i] = InputByte1[position];
                    position++;
                }
                mass[index] += extra + " / " + convertFromByteArrayIoInt(toInt4);
                extra = "";
                index++;
                ///////////////////////////////////////////////////////////////// разветвление на CORE и не CORE
                /*   CORE   */
                if (!(type == "not intedeficated"))
                    if (type == "CORE")
                    {
                        // bcPlanes
                        mass[index] = "(length: 2 bytes) (количество уровней) bcPlanes: ";
                        for (int i = 0; i < checkCORE; i++)
                        {
                            // massInfo[index] += InputByte1[position].ToString() + " ";
                            extra = InputByte1[position].ToString("X2") + " " + extra;
                            toInt2[i] = InputByte1[position];
                            position++;
                        }
                        mass[index] += extra + " / " + convertFromByteArrayIoInt(toInt2);
                        extra = "";
                        index++;
                        // bcBitCount
                        mass[index] = "(length: 2 bytes) (количество бит на пиксель) bcBitCount: ";
                        for (int i = 0; i < checkCORE; i++)
                        {
                            // massInfo[index] += InputByte1[position].ToString() + " ";
                            extra = InputByte1[position].ToString("X2") + " " + extra;
                            toInt2[i] = InputByte1[position];
                            position++;
                        }
                        mass[index] += extra + " / " + convertFromByteArrayIoInt(toInt2);
                        extra = "";
                        index++;
                    }
                    else // всё остальное
                    {
                        // Planes
                        mass[index] = "(length: 2 bytes) (количество уровней) Planes: ";
                        for (int i = 0; i < word; i++)
                        {
                            // massInfo[index] += InputByte1[position].ToString() + " ";
                            extra = InputByte1[position].ToString("X2") + " " + extra;
                            toInt2[i] = InputByte1[position];
                            position++;
                        }
                        mass[index] += extra + " / " + convertFromByteArrayIoInt(toInt2);
                        extra = "";
                        index++;
                        // BitCount
                        mass[index] = "(length: 2 bytes) (количество бит на пиксель) BitCount: ";
                        for (int i = 0; i < word; i++)
                        {
                            // massInfo[index] += InputByte1[position].ToString() + " ";
                            extra = InputByte1[position].ToString("X2") + " " + extra;
                            toInt2[i] = InputByte1[position];
                            position++;
                        }
                        mass[index] += extra + " / " + convertFromByteArrayIoInt(toInt2);
                        extra = "";
                        index++;
                        // Compression
                        mass[index] = "(length: 4 bytes) (способ хранения пикселей) Compression: ";
                        for (int i = 0; i < checkCORE; i++)
                        {
                            // massInfo[index] += InputByte1[position].ToString() + " ";
                            extra = InputByte1[position].ToString("X2") + " " + extra;
                            toInt4[i] = InputByte1[position];
                            position++;
                        }
                        mass[index] += extra + " / " + convertFromByteArrayIoInt(toInt4);
                        extra = "";
                        index++;
                        // SizeImage
                        mass[index] = "(length: 4 bytes) (размер пиксельных данных (в байтах)) SizeImage: ";

                        for (int i = 0; i < checkCORE; i++)
                        {
                            // massInfo[index] += InputByte1[position].ToString() + " ";
                            extra = InputByte1[position].ToString("X2") + " " + extra;
                            toInt4[i] = InputByte1[position];
                            position++;
                        }
                        mass[index] += extra + " / " + convertFromByteArrayIoInt(toInt4);
                        extra = "";
                        index++;
                        // XPerlsPerMeter
                        mass[index] = "(length: 4 bytes) (пикселей на метр (по Х)) XPerlsPerMeter: ";

                        for (int i = 0; i < checkCORE; i++)
                        {
                            // massInfo[index] += InputByte1[position].ToString() + " ";
                            extra = InputByte1[position].ToString("X2") + " " + extra;
                            toInt4[i] = InputByte1[position];
                            position++;
                        }
                        mass[index] += extra + " / " + convertFromByteArrayIoInt(toInt4);
                        extra = "";
                        index++;
                        // YPerlsPerMeter
                        mass[index] = "(length: 4 bytes) (пикселей на метр (по Y)) YPerlsPerMeter: ";

                        for (int i = 0; i < checkCORE; i++)
                        {
                            // massInfo[index] += InputByte1[position].ToString() + " ";
                            extra = InputByte1[position].ToString("X2") + " " + extra;
                            toInt4[i] = InputByte1[position];
                            position++;
                        }
                        mass[index] += extra + " / " + convertFromByteArrayIoInt(toInt4);
                        extra = "";
                        index++;
                        // CirUsed
                        mass[index] = "(length: 4 bytes) (размер таблицы цветов в ячейках) CirUsed: ";
                        for (int i = 0; i < checkCORE; i++)
                        {
                            // massInfo[index] += InputByte1[position].ToString() + " ";
                            extra = InputByte1[position].ToString("X2") + " " + extra;
                            toInt4[i] = InputByte1[position];
                            position++;
                        }
                        mass[index] += extra + " / " + convertFromByteArrayIoInt(toInt4);
                        extra = "";
                        index++;
                        // CirImportant
                        mass[index] = "(length: 4 bytes) (общее количество ячеек от начала таблицы до последней используемой) CirImportant: ";
                        for (int i = 0; i < checkCORE; i++)
                        {
                            // massInfo[index] += InputByte1[position].ToString() + " ";
                            extra = InputByte1[position].ToString("X2") + " " + extra;
                            toInt4[i] = InputByte1[position];
                            position++;
                        }
                        mass[index] += extra + " / " + convertFromByteArrayIoInt(toInt4);
                        extra = "";
                        index++;
                        //////////////////////////////////////////////////////////////////////////////////////// отделение 3 версии от остальных
                        if (!(type == "ver 3"))
                        {
                            // RedMask
                            mass[index] = "(length: 4 bytes) (битовая маска для извлечения красного канала) RedMask: ";

                            for (int i = 0; i < checkCORE; i++)
                            {
                                // massInfo[index] += InputByte1[position].ToString() + " ";
                                extra = InputByte1[position].ToString("X2") + " " + extra;
                                toInt4[i] = InputByte1[position];
                                position++;
                            }
                            mass[index] += extra + " / " + convertFromByteArrayIoInt(toInt4);
                            extra = "";
                            index++;
                            // GreenMask
                            mass[index] = "(length: 4 bytes) (битовая маска для извлечения зелёного канала) GreenMask: ";
                            for (int i = 0; i < checkCORE; i++)
                            {
                                // massInfo[index] += InputByte1[position].ToString() + " ";
                                extra = InputByte1[position].ToString("X2") + " " + extra;
                                toInt4[i] = InputByte1[position];
                                position++;
                            }
                            mass[index] += extra + " / " + convertFromByteArrayIoInt(toInt4);
                            extra = "";
                            index++;
                            // BlueMask
                            mass[index] = "(length: 4 bytes) (битовая маска для извлечения синего канала) BlueMask: ";
                            for (int i = 0; i < checkCORE; i++)
                            {
                                // massInfo[index] += InputByte1[position].ToString() + " ";
                                extra = InputByte1[position].ToString("X2") + " " + extra;
                                toInt4[i] = InputByte1[position];
                                position++;
                            }
                            mass[index] += extra + " / " + convertFromByteArrayIoInt(toInt4);
                            extra = "";
                            index++;
                            // AlfaMask
                            mass[index] = "(length: 4 bytes) (битовая маска для извлечения альфа канала) AlfaMask: ";
                            for (int i = 0; i < checkCORE; i++)
                            {
                                // massInfo[index] += InputByte1[position].ToString() + " ";
                                extra = InputByte1[position].ToString("X2") + " " + extra;
                                toInt4[i] = InputByte1[position];
                                position++;
                            }
                            mass[index] += extra + " / " + convertFromByteArrayIoInt(toInt4);
                            extra = "";
                            index++;
                            // CSType
                            mass[index] = "(length: 4 bytes) (вид цветового пространства) CSType: ";
                            for (int i = 0; i < checkCORE; i++)
                            {
                                // massInfo[index] += InputByte1[position].ToString() + " ";
                                extra = InputByte1[position].ToString("X2") + " " + extra;
                                toInt4[i] = InputByte1[position];
                                position++;
                            }
                            mass[index] += extra + " / " + convertFromByteArrayIoInt(toInt4);
                            extra = "";
                            index++;
                            // Endpoints
                            mass[index] = "(length: 36 bytes) Endpoints: ";
                            for (int i = 0; i < revese36.Length; i++)
                            {
                                // massInfo[index] += InputByte1[position].ToString() + " ";
                                extra = InputByte1[position].ToString("X2") + " " + extra;
                                //revese36[i] = InputByte1[position];
                                position++;
                            }
                            mass[index] += extra;
                            extra = "";
                            index++;
                            // GammaRed
                            mass[index] = "(length: 4 bytes) GammaRed: ";

                            for (int i = 0; i < checkCORE; i++)
                            {
                                // massInfo[index] += InputByte1[position].ToString() + " ";
                                extra = InputByte1[position].ToString("X2") + " " + extra;
                                toInt4[i] = InputByte1[position];
                                position++;
                            }
                            mass[index] += extra + " / " + convertFromByteArrayIoInt(toInt4);
                            extra = "";
                            index++;
                            // GammaGreen
                            mass[index] = "(length: 4 bytes) GammaGreen: ";

                            for (int i = 0; i < checkCORE; i++)
                            {
                                // massInfo[index] += InputByte1[position].ToString() + " ";
                                extra = InputByte1[position].ToString("X2") + " " + extra;
                                toInt4[i] = InputByte1[position];
                                position++;
                            }
                            mass[index] += extra + " / " + convertFromByteArrayIoInt(toInt4);
                            extra = "";
                            index++;
                            // GammaBlue
                            mass[index] = "(length: 4 bytes) GammaBlue: ";

                            for (int i = 0; i < checkCORE; i++)
                            {
                                // massInfo[index] += InputByte1[position].ToString() + " ";
                                extra = InputByte1[position].ToString("X2") + " " + extra;
                                toInt4[i] = InputByte1[position];
                                position++;
                            }
                            mass[index] += extra + " / " + convertFromByteArrayIoInt(toInt4);
                            extra = "";
                            index++;
                            if (type == "ver 5") // часть заголовка, которая появилась только в 5ой версии
                            {
                                // Intent
                                mass[index] = "(length: 4 bytes) (предпочтение при рендеринге растра) Intent: ";

                                for (int i = 0; i < checkCORE; i++)
                                {
                                    // massInfo[index] += InputByte1[position].ToString() + " ";
                                    extra = InputByte1[position].ToString("X2") + " " + extra;
                                    toInt4[i] = InputByte1[position];
                                    position++;
                                }


                                mass[index] += extra + " / " + convertFromByteArrayIoInt(toInt4);
                                extra = "";
                                index++;



                                // ProfileData
                                mass[index] = "(length: 4 bytes) (смещение в байтах цветового профиля) ProfileData: ";

                                for (int i = 0; i < checkCORE; i++)
                                {
                                    // massInfo[index] += InputByte1[position].ToString() + " ";
                                    extra = InputByte1[position].ToString("X2") + " " + extra;
                                    toInt4[i] = InputByte1[position];
                                    position++;
                                }


                                mass[index] += extra + " / " + convertFromByteArrayIoInt(toInt4);
                                extra = "";
                                index++;


                                // ProfileSize
                                mass[index] = "(length: 4 bytes) (размер цветового профиля) ProfileSize: ";

                                for (int i = 0; i < checkCORE; i++)
                                {
                                    // massInfo[index] += InputByte1[position].ToString() + " ";
                                    extra = InputByte1[position].ToString("X2") + " " + extra;
                                    toInt4[i] = InputByte1[position];
                                    position++;
                                }


                                mass[index] += extra + " / " + convertFromByteArrayIoInt(toInt4);
                                extra = "";
                                index++;


                                // Reserved
                                mass[index] = "(length: 4 bytes) (зарезервированные пустые биты) Reserved: ";

                                for (int i = 0; i < checkCORE; i++)
                                {
                                    // massInfo[index] += InputByte1[position].ToString() + " ";
                                    extra = InputByte1[position].ToString("X2") + " " + extra;
                                    // toInt4[i] = InputByte1[position];
                                    position++;
                                }


                                mass[index] += extra;
                                extra = "";
                                index++;
                            }
                        }
                    }
                foreach (var aaaaaa in mass)
                    writer.WriteLine(aaaaaa);
      
                writer.Close();
            }
        }

    }
}